# SSAO Demo

Software component of the *Screen-space Secondary Lighting* dissertation project by Dale Whinham.

## Usage

Mouse is used for looking around.

| Key        | Command                                                                         |
|------------|---------------------------------------------------------------------------------|
| W, A, S, D | Movement                                                                        |
| T          | Draw mode - cycles between composite scene, SSAO texture, and G-buffer textures |
| O          | Toggle SSAO on/off                                                              |
| P          | Toggle SSAO blur filter on/off                                                  |
| - and +    | Adjust SSAO sample count (powers of two from 4 to 128)                          |
| [ and ]    | Adjust ambient lighting factor                                                  |
| ; and '    | Adjust SSAO sampling radius                                                     |
